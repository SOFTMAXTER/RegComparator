import re
import sys
import codecs # Para manejar posibles codificaciones como UTF-16
import os     # Necesario para manejar rutas de archivos y directorios
import datetime # Para la fecha y hora en el reporte

# --- INICIO: PATRONES DE EXCLUSIÓN ---
# Agrega aquí las rutas de claves del registro (o sus prefijos) que deseas excluir de la comparación.
# Las comparaciones son insensibles a mayúsculas/minúsculas para los patrones.
EXCLUSION_PATTERNS = [
    # --- Configuración Regional y de Idioma ---
    r"HKEY_CURRENT_USER\Control Panel\International",
    r"HKEY_CURRENT_USER\Software\Microsoft\InputMethod", # Métodos de entrada, teclados
    r"HKEY_CURRENT_USER\Software\Microsoft\CTF", # Common Text Framework (idioma)
    r"HKEY_CURRENT_USER\Keyboard Layout",
    r"HKEY_USERS\.DEFAULT\Control Panel\International", # Plantilla para nuevos usuarios
    r"HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Nls", # National Language Support
    r"HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Keyboard Layouts",
    r"HKEY_LOCAL_MACHINE\COMPONENTS\CanonicalData\Deployments",
    r"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\SideBySide\Winners",
    r"HKEY_CURRENT_USER\Control Panel\Desktop\MuiCached", # Cache de UI multilingüe

    # --- Actualizaciones de Windows y Componentes (Ejemplos) ---
    # Ser específico aquí para no excluir demasiado.
    r"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\Packages",
    r"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\SessionsPending",
    r"HKEY_LOCAL_MACHINE\COMPONENTS\CanonicalData\Catalogs",
    r"HKEY_LOCAL_MACHINE\COMPONENTS\DerivedData\Components",
    r"HKEY_LOCAL_MACHINE\COMPONENTS\DerivedData\VersionedIndex",
    r"HKEY_LOCAL_MACHINE\SCHEMA",
    r"HKEY_LOCAL_MACHINE\SOFTWARE\Classes",
    r"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\.NETFramework",
    r"HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Microsoft\.NETFramework",
    r"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Office",
    r"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Fusion",
    r"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Appx",
    r"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing",
    r"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Installer",
    r"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\AppReadiness",
    r"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Installer",
    r"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Setup",
    r"HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Classes\CLSID",
    r"HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Classes\Interface",
    r"HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Classes\TypeLib",
    r"HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Setup",
    r"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\TaskCache\Tree\Microsoft\Windows\UpdateOrchestrator", # Programador de tareas de actualización
    # Podrías necesitar añadir rutas específicas de KB (ej. HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Updates\Windows XP\SP4\KB123456)
    # O ser más general si confías, ej: r"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Updates"

    # --- Cache y datos temporales (Ejemplos) ---
    r"HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\ComDlg32\LastVisitedMRU", # Archivos recientes
    r"HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\RecentDocs",
    r"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\AppModel\StateRepository\Cache",
    r"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\TaskCache",
    # Puedes añadir más patrones según lo que observes que cambia frecuentemente y no es relevante
]
# --- FIN: PATRONES DE EXCLUSIÓN ---

def is_excluded(key_path, patterns):
    key_path_lower = key_path.lower()
    for pattern in patterns:
        if key_path_lower.startswith(pattern.lower()):
            return True
    return False

def parse_reg_file(filepath):
    registry_data = {}
    current_key = None
    encodings_to_try = ['utf-16', 'utf-8']
    file_content = None
    parsing_successful = False

    for enc in encodings_to_try:
        try:
            with codecs.open(filepath, 'r', encoding=enc, errors='ignore') as f:
                file_content = f.readlines()
            print(f"Archivo '{filepath}' leído exitosamente con codificación {enc}.")
            parsing_successful = True
            break
        except FileNotFoundError:
            print(f"Error: Archivo no encontrado en la ruta: {filepath}")
            return None
        except Exception as e:
            print(f"Advertencia: Falló la lectura de '{filepath}' con {enc} ({type(e).__name__}). Intentando siguiente...")

    if not parsing_successful or file_content is None:
        print(f"Error: No se pudo leer el archivo '{filepath}' con las codificaciones probadas.")
        return None

    if file_content and file_content[0].startswith('\ufeff'):
        file_content[0] = file_content[0][1:]

    if file_content and "Windows Registry Editor Version" in file_content[0]:
         file_content = file_content[1:]

    for line in file_content:
        line = line.strip()
        if not line or line.startswith(';'):
            continue
        key_match = re.match(r'^\[(.+)\]$', line)
        if key_match:
            current_key = key_match.group(1).strip()
            if current_key not in registry_data:
                registry_data[current_key] = {}
            continue
        if current_key and '=' in line:
            value_match = re.match(r'^("?.*?"?|@)=(.*)$', line)
            if value_match:
                value_name = value_match.group(1).strip()
                if value_name.startswith('"') and value_name.endswith('"'):
                     value_name = value_name[1:-1]
                value_data = value_match.group(2).strip()
                registry_data[current_key][value_name] = value_data
            else:
                 print(f"Advertencia: Línea de valor no reconocida en [{current_key}]: {line}")
    return registry_data

def compare_registries(original_data, changed_data, exclusion_patterns=None):
    if original_data is None or changed_data is None: return None
    if exclusion_patterns is None: exclusion_patterns = []

    original_keys_filtered = {
        k for k in original_data.keys() if not is_excluded(k, exclusion_patterns)
    }
    changed_keys_filtered = {
        k for k in changed_data.keys() if not is_excluded(k, exclusion_patterns)
    }

    added_key_paths = changed_keys_filtered - original_keys_filtered
    # Sigue siendo necesario calcular deleted_key_paths para determinar common_key_paths correctamente
    deleted_key_paths = original_keys_filtered - changed_keys_filtered 
    common_key_paths = original_keys_filtered.intersection(changed_keys_filtered)

    differences = {
        "added_keys_details": {},
        "deleted_keys_details": {}, # Se mantendrá vacío
        "modified_keys": {}
    }

    # Poblar detalles para claves añadidas
    for key_path in sorted(list(added_key_paths)):
        differences["added_keys_details"][key_path] = changed_data.get(key_path, {})

    # NO Poblar detalles para claves eliminadas
    # El bucle para deleted_key_paths se omite para no llenar differences["deleted_keys_details"]
        
    for key_path in sorted(list(common_key_paths)):
        original_values = original_data[key_path]
        changed_values = changed_data[key_path]
        original_value_names = set(original_values.keys())
        changed_value_names = set(changed_values.keys())
        
        added_values_in_key = changed_value_names - original_value_names
        deleted_values_in_key = original_value_names - changed_value_names
        common_values_in_key = original_value_names.intersection(changed_value_names)

        key_diffs = {
            "added": {v_name: changed_values[v_name] for v_name in sorted(list(added_values_in_key))},
            "deleted": {v_name: original_values[v_name] for v_name in sorted(list(deleted_values_in_key))},
            "modified": {}
        }

        for v_name in sorted(list(common_values_in_key)):
            if original_values[v_name] != changed_values[v_name]:
                key_diffs["modified"][v_name] = {
                    "original": original_values[v_name],
                    "changed": changed_values[v_name]
                }
        
        if key_diffs["added"] or key_diffs["deleted"] or key_diffs["modified"]:
            differences["modified_keys"][key_path] = key_diffs
            
    return differences

def format_differences_string(diffs, file1_name="Original", file2_name="Modificado", exclusion_patterns_active=None):
    if diffs is None: return "No se pudieron generar las diferencias debido a errores previos."

    report_lines = []
    report_lines.append("--- Resumen de Diferencias (Solo Añadidos y Modificados) ---")
    report_lines.append(f"Comparando '{os.path.basename(file1_name)}' contra '{os.path.basename(file2_name)}'")
    report_lines.append("-" * 30)

    if exclusion_patterns_active:
        report_lines.append("Patrones de Exclusión Activos (claves que comienzan con):")
        for pattern in exclusion_patterns_active:
            report_lines.append(f"  - {pattern}")
        report_lines.append("-" * 30)

    found_diffs = False

    # Mostrar detalles para claves añadidas
    if diffs["added_keys_details"]:
        found_diffs = True
        report_lines.append(f"[+] Claves Añadidas en '{os.path.basename(file2_name)}' (no excluidas):")
        for key_path, values_dict in diffs["added_keys_details"].items():
            report_lines.append(f"  + [{key_path}]:")
            if values_dict:
                for v_name, v_data in sorted(values_dict.items()):
                    report_lines.append(f'      -> "{v_name}" = {v_data}')
            else:
                report_lines.append(f'      (Clave vacía o sin valores directos listados)')
        report_lines.append("-" * 20)

    # NO Mostrar detalles para claves eliminadas
    # La sección if diffs["deleted_keys_details"]: ha sido eliminada.

    if diffs["modified_keys"]:
        found_diffs = True
        report_lines.append(f"[*] Claves Modificadas (no excluidas):")
        for key_path, key_diff in diffs["modified_keys"].items():
            report_lines.append(f"  * [{key_path}]:")
            if key_diff["added"]:
                report_lines.append("    [+] Valores Añadidos:")
                for v_name, v_data in key_diff["added"].items():
                    report_lines.append(f'      + "{v_name}" = {v_data}')
            if key_diff["deleted"]:
                report_lines.append("    [-] Valores Eliminados:") # Estos son valores eliminados DENTRO de una clave modificada
                for v_name, v_data in key_diff["deleted"].items():
                    report_lines.append(f'      - "{v_name}" = {v_data}')
            if key_diff["modified"]:
                report_lines.append("    [*] Valores Modificados:")
                for v_name, v_diff_data in key_diff["modified"].items():
                    report_lines.append(f'      * "{v_name}":')
                    report_lines.append(f'          Original:   {v_diff_data["original"]}')
                    report_lines.append(f'          Modificado: {v_diff_data["changed"]}')
        report_lines.append("-" * 20)

    if not found_diffs:
        message = "¡No se encontraron claves añadidas o modificadas "
        if exclusion_patterns_active: message += "aplicando los filtros de exclusión!"
        else: message += "entre los dos archivos!"
        report_lines.append(message)
            
    return "\n".join(report_lines)

def print_console_report(report_string):
    if not report_string:
        print("No se pudo generar el reporte debido a errores previos.")
        return
    print("\n--- Reporte de Comparación (Consola) ---")
    print(report_string)
    print("--- Fin del Reporte (Consola) ---")

# --- Inicio de la ejecución ---
if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Uso: python comparar_reg.py <archivo_reg_original> <archivo_reg_modificado>")
        file1_path = input("Introduce la ruta al archivo .reg ORIGINAL: ")
        file2_path = input("Introduce la ruta al archivo .reg MODIFICADO: ")
    else:
        file1_path = sys.argv[1]
        file2_path = sys.argv[2]

    print(f"Parseando archivo original: {file1_path}")
    original_registry = parse_reg_file(file1_path)

    print(f"\nParseando archivo modificado: {file2_path}")
    changed_registry = parse_reg_file(file2_path)

    if original_registry is not None and changed_registry is not None:
        print(f"\nAplicando {len(EXCLUSION_PATTERNS)} patrones de exclusión.")
        differences = compare_registries(original_registry, changed_registry, EXCLUSION_PATTERNS)

        abs_file1_path = os.path.abspath(file1_path)
        abs_file2_path = os.path.abspath(file2_path)
        
        report_content = format_differences_string(differences, abs_file1_path, abs_file2_path, EXCLUSION_PATTERNS)

        print_console_report(report_content)

        try:
            # Determinar la ruta del script para guardar el reporte en el directorio padre
            # Esto puede fallar si se ejecuta desde un entorno empaquetado (ej. PyInstaller sin ajustes)
            try:
                script_path_real = os.path.realpath(__file__)
                script_dir = os.path.dirname(script_path_real)
            except NameError: # __file__ no está definido (ej. intérprete interactivo, o empaquetado)
                script_dir = os.getcwd() # Usar directorio actual como fallback
                print(f"Advertencia: No se pudo determinar la ruta del script, el reporte se guardará en: {script_dir}")

            parent_dir = os.path.dirname(script_dir) if script_dir != os.path.dirname(script_dir) else script_dir # Evitar ir "más arriba" del root
            
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            output_filename = f"registry_comparison_report_{timestamp}.txt"
            output_filepath = os.path.join(parent_dir, output_filename)

            print(f"\nGuardando reporte detallado en: {output_filepath}")
            with open(output_filepath, 'w', encoding='utf-8') as outfile:
                outfile.write(f"Reporte de comparación (Solo Añadidos y Modificados) generado el: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                outfile.write(f"Archivo Original:   {abs_file1_path}\n")
                outfile.write(f"Archivo Modificado: {abs_file2_path}\n\n")
                if EXCLUSION_PATTERNS:
                    outfile.write("Patrones de Exclusión Aplicados (claves que comienzan con):\n")
                    for pattern in EXCLUSION_PATTERNS:
                        outfile.write(f"  - {pattern}\n")
                    outfile.write("\n")
                outfile.write("="*40 + "\n\n")
                outfile.write(report_content)
            print("Reporte guardado exitosamente.")
        except Exception as e:
            print(f"\nError al intentar guardar el archivo de reporte en '{parent_dir}': {e}")
            print("Asegúrate de que el script tiene permisos de escritura en ese directorio.")
    else:
         print("\nNo se pudo proceder con la comparación debido a errores al leer los archivos.")

    input("\nPresiona Enter para finalizar el script...")